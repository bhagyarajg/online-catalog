/**
 * Created by bhagyaraj on 1/7/2017.
 */


var app=angular.module("myModule",[])
    .controller("myController",function($scope,$http){
      
        $scope.getSelectedQuantity = 0;
        $scope.selectedObj = {
            selectedQuantity:0
        }
        $scope.successVal = false;
        $scope.hideVal=false;

        $http.post("widgetsData.php",{'do':'getWidgetsData'}).then(function(res){
            $scope.items = res.data
        },function(err){
            console.log('error in call')
        });
        $scope.orderItems=function(getSelectedItem,selectedQuantity,itemname){
            
            var widSelected;
            if(itemname === 'Micro Sensor 3000'){
                widSelected=getSelectedItem.wid;
            }else{
                widSelected=getSelectedItem[0].wid;
            }

            $http.post("widgetsData.php",{'do':'updateWidgetData','wid':widSelected,'selectedQuantity':selectedQuantity}).then(function(res){
                alert("Order has been placed successfully");
                //$scope.successVal = true;
                window.location.href="index.html";
            },function(err){
                console.log('error in call')
            });
        }

        $scope.getQuantity= function (item,selectedSize){
             $scope.getSelectedItem = $scope.items.filter(function(d){
                 return item.name === d.name && d.size === selectedSize
             });

            //$scope.newObj=angular.extend(newObj,$scope.getSelectedItem);
            $(document.querySelectorAll('.hide-show')).addClass('hideMsg');
            $(document.querySelectorAll('.size-butn')).removeClass('active');
            $(event.target).addClass('active');

            $scope.successVal = true;

            $scope.getSelectedQuantity = $scope.getSelectedItem[0].quantity;
            $scope.getSelectedPrice = $scope.getSelectedItem[0].price;

        }

    })
    .filter('range', function() {
        return function(input, min, max) {
            min = parseInt(min); //Make string input int
            max = parseInt(max);
            for (var i=min; i<=max; i++)
                input.push(i);
            return input;
        };
    })

.filter('unique', function() {
    // we will return a function which will take in a collection
    // and a keyname
    return function(collection, keyname) {
        // we define our output and keys array;
        var output = [],
            keys = [];

        // we utilize angular's foreach function
        // this takes in our original collection and an iterator function
        angular.forEach(collection, function(item) {
            // we check to see whether our object exists
            var key = item[keyname];
            // if it's not already part of our keys array
            if(keys.indexOf(key) === -1) {
                // add it to our keys array
                keys.push(key);
                // push this item to our final output array
                output.push(item);
            }
        });
        // return our array which should be devoid of
        // any duplicates
        return output;
    };
});
