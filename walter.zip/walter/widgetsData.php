<?php
/**
 * Created by PhpStorm.
 * User: bhagyaraj
 * Date: 1/7/2017
 * Time: 4:04 PM
 */

include_once("connection.php");
if (!$conn) {
    echo "not connected";
} else {
    $data = json_decode(file_get_contents("php://input"));
     $do=$data->do;
       if ($do == "getWidgetsData") {
            $widgetsQuery = "SELECT * FROM widgetstable";
            $executeWidgetList = mysqli_query($conn, $widgetsQuery);
            $widgets_arr = array();

            while ($row = mysqli_fetch_assoc($executeWidgetList)) {

                $widget_row = array('wid' =>$row["WID"],
                    'name' => $row["Name"],
                    'size' => $row["Size"],
                    'price' => $row["Price"],
                    'quantity' => $row["Quantity"],
                    'imgSrc' => $row["ImageSrc"],
                    'description' => $row["Description"]
                );
                array_push($widgets_arr, $widget_row);
            }
            echo json_encode($widgets_arr);

        } else if($do =='updateWidgetData'){
           $wid=$data -> wid;
           $selectedQuantity=$data ->selectedQuantity;
           $widgetsQuery = "UPDATE widgetstable SET Quantity=Quantity-'$selectedQuantity' WHERE WID='$wid' ";
           $executeWidgetList = mysqli_query($conn, $widgetsQuery);
           echo "updated";
       }
        mysqli_close($conn);
}
?>

