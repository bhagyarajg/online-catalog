<?php 

$server = "localhost";
$username="root";
$password="";
$database="walterdb";

$conn = mysqli_connect($server,$username,$password,$database);

if (!$conn){
	echo "not connected";
}

?>