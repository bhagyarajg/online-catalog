UI Code test 

Please follow the below instructions to run this code: 


 1) Please install WAMP / LAMP server based upon your platform(Windows or Linux). I used "WAMP server" for my Windows platform.

 2) Upon installing , you will find "wamp" folder in your C directory. Please go to that directory and unzip "walter.zip" there.
	 	

 3) This application needs database connectivity.
	For that, go to this URL"http://localhost/phpmyadmin" and create a dabase with name "walterdb" then import "widgetstable.sql"(avaliable in the unzipped directory "walter") into it. 

 4) And open this URL "http://localhost/walter/index.html" and you will see the application running.




 
 
 
 