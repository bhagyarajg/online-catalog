-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2017 at 04:16 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `walterdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `widgetstable`
--

CREATE TABLE IF NOT EXISTS `widgetstable` (
  `WID` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Size` varchar(10) NOT NULL,
  `Price` float NOT NULL,
  `Quantity` int(10) NOT NULL,
  `ImageSrc` varchar(200) NOT NULL,
  `Description` varchar(300) NOT NULL,
  PRIMARY KEY (`WID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `widgetstable`
--

INSERT INTO `widgetstable` (`WID`, `Name`, `Size`, `Price`, `Quantity`, `ImageSrc`, `Description`) VALUES
(1, 'Acme Super Greased Cogwheel', 'Small', 1, 10, 'img/wheel.jpg', 'This toothy monster can be combined to create the smoothest change in speed or direction of the motion.'),
(2, 'Acme Super Greased Cogwheel', 'Medium', 1.5, 5, 'img/wheel.jpg', 'This toothy monster can be combined to create the smoothest change in speed or direction of the motion.'),
(3, 'Acme Super Greased Cogwheel', 'Large', 3, 8, 'img/wheel.jpg', 'This toothy monster can be combined to create the smoothest change in speed or direction of the motion.'),
(6, 'Micro Sensor 3000', '', 12, 12, 'img/micro_sensor.jpg', 'Even the tiniest variation in the magnetism will trigger this little wonder'),
(7, 'Twirly Whirly', 'Small', 10, 15, 'img/rotator.jpg', 'Give the power of flight to your contraptions with these light-weight motorized rotors.'),
(8, 'Twirly Whirly', 'Medium', 12.75, 14, 'img/rotator.jpg', 'Give the power of flight to your contraptions with these light-weight motorized rotors.');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
