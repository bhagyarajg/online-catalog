/**
 * Created by bhagyaraj.
 */


var app=angular.module("myModule",[])
    .controller("myController",function($scope,$http){
      
        $scope.getSelectedQuantity = 0;
        $scope.selectedObj = {
            selectedQuantity:0
        }

        $scope.hideVal=false;
        $scope.highlightVal=true;

        $http.post("widgetsData.php",{do:'getWidgetsData'}).then(function(res){
            $scope.items = res.data;
		},function(err){
            console.log('error in call')
        });

        $scope.orderItems=function(getSelectedItem,selectedQuantity,itemname){          
            var widSelected;
            if(itemname === 'Micro Sensor 3000'){
                widSelected=getSelectedItem.wid;
            }else{
                widSelected=getSelectedItem[0].wid;
            }
            $http.post("widgetsData.php",{'do':'updateWidgetData','wid':widSelected,'selectedQuantity':selectedQuantity}).then(function(res){
                if(res.data.trim()=="updated"){
                    alert("Order has been placed successfully");
                    window.location.href="index.html";
                }
            },function(err){
                console.log('error in call')
            });
        }
        $scope.closeModal=function(){
            $(".modal").modal('hide');
        }
        $scope.getQuantity= function (item,selectedSize,event){
             $scope.getSelectedItem = $scope.items.filter(function(d){
                 return item.name === d.name && d.size === selectedSize
             });
            $scope.getSelectedQuantity = $scope.getSelectedItem[0].quantity;
            $scope.getSelectedPrice = $scope.getSelectedItem[0].price;

            $(document.querySelectorAll('.size-butn')).removeClass('active');

            $(event.target).addClass('active');

            $scope.successVal = true;
        }

    })
	
    .filter('range', function() {
        return function(input, min, max) {
            min = parseInt(min); 
            for (var i=min; i<=max; i++)
                input.push(i);
            return input;
        };
    })

	.filter('unique', function() {
		return function(collection, keyname) {
			var output = [],
				keys = []; 
				angular.forEach(collection, function(item) {
				
					var key = item[keyname];
					
					if(keys.indexOf(key) === -1) {
					
						keys.push(key);
						
						output.push(item);
				}
			});
			
			return output;
		};
});
